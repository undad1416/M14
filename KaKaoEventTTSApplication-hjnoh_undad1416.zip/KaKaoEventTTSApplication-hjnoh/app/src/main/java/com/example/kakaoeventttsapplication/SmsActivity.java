package com.example.kakaoeventttsapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

// SMS 메시지가 오면 화면에 표시 해주는 Activity
public class SmsActivity extends AppCompatActivity {
   EditText editTextSend;
   EditText editTextContent;
   Button button;
   String string2="";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        editTextContent = (EditText)findViewById(R.id.contentsText);
        editTextSend = findViewById(R.id.senderText);
        Intent passedIntent = getIntent();
        processIntent(passedIntent);

        button = findViewById(R.id.close);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        finish();
    }
    private void processIntent(Intent intent){
        if(intent != null){
            String contents = intent.getStringExtra("contents");
            editTextContent.setText(contents);
            String sender = intent.getStringExtra("sender");
            editTextSend.setText(sender);
            string2+=sender+contents;
//            new AlertDialog.Builder(SmsActivity.this) // TestActivity 부분에는 현재 Activity의 이름 입력.
//                    .setMessage("AlertDialog 테스트"+string2)     // 제목 부분 (직접 작성)
//                    .setPositiveButton("확인", new DialogInterface.OnClickListener() {      // 버튼1 (직접 작성)
//                        public void onClick(DialogInterface dialog, int which){
//                            Toast.makeText(getApplicationContext(), "확인 누름", Toast.LENGTH_SHORT).show(); // 실행할 코드
//                        }
//                    })
//                    .setNegativeButton("취소", new DialogInterface.OnClickListener() {     // 버튼2 (직접 작성)
//                        public void onClick(DialogInterface dialog, int which){
//                            Toast.makeText(getApplicationContext(), "취소 누름", Toast.LENGTH_SHORT).show(); // 실행할 코드
//                        }
//                    })
//                    .show();
//            Toast myToast = Toast.makeText(this.getApplicationContext(),string2, Toast.LENGTH_SHORT);
//            myToast.show();

        }
    }
    @Override
    protected void onNewIntent(Intent intent) {
        processIntent(intent);
        super.onNewIntent(intent);
    }
}
// SMS 메시지 끝

